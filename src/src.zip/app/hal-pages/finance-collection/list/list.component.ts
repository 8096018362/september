import { Component } from "@angular/core";

@Component({
    selector: '',
    templateUrl: './list.component.html',
    //  styleUrls: ['./list.component.scss']

})

export class ListComponent {

}
