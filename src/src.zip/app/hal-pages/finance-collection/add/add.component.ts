import { Component } from "@angular/core";

@Component({
    selector: '',
    templateUrl: './add.component.html',
    styleUrls: ['./add.component.scss']

})

export class AddComponent {

}
