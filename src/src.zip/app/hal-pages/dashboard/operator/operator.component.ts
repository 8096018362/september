import { Component } from "@angular/core";

@Component({
    selector: '',
    templateUrl: './operator.component.html',
    styleUrls: ['./operator.component.scss']

})

export class OperatorComponent {

}
