import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timeline2',
  templateUrl: './timeline2.component.html',
  styleUrls: ['./timeline2.component.scss']
})
export class Timeline2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
